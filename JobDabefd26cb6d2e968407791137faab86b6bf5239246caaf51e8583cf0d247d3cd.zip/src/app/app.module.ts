import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { AccueilProPage } from '../pages/accueil-pro/accueil-pro';
import { ProfilStagiaireVueProPage } from '../pages/profil-stagiaire-vue-pro/profil-stagiaire-vue-pro';
import { PageDasboardProPage } from '../pages/page-dasboard-pro/page-dasboard-pro';
import { ConnectionPage } from '../pages/connection/connection';
import { CreationStagiairePage } from '../pages/creation-stagiaire/creation-stagiaire';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    AccueilProPage,
    ProfilStagiaireVueProPage,
    PageDasboardProPage,
    ConnectionPage,
    CreationStagiairePage
    
    ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    AccueilProPage,
    ProfilStagiaireVueProPage,
    PageDasboardProPage,
    ConnectionPage,
    CreationStagiairePage
    
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
