import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PageDasboardProPage } from './page-dasboard-pro';

@NgModule({
  declarations: [
    PageDasboardProPage,
  ],
  imports: [
    IonicPageModule.forChild(PageDasboardProPage),
  ],
})
export class PageDasboardProPageModule {}
