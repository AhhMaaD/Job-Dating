import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ProfilStagiaireVueProPage } from '../profil-stagiaire-vue-pro/profil-stagiaire-vue-pro';

/**
 * Generated class for the PageDasboardProPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-page-dasboard-pro',
  templateUrl: 'page-dasboard-pro.html',
})
export class PageDasboardProPage {
  users = new Array(10);

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PageDasboardProPage');
  }
  goToProfil(){
    this.navCtrl.push(ProfilStagiaireVueProPage);
  }
  goBack() {
    this.navCtrl.pop();
  }
}
