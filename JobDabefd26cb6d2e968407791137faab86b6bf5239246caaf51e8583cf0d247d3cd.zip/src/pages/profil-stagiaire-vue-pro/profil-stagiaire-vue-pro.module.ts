import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProfilStagiaireVueProPage } from './profil-stagiaire-vue-pro';

@NgModule({
  declarations: [
    ProfilStagiaireVueProPage,
  ],
  imports: [
    IonicPageModule.forChild(ProfilStagiaireVueProPage),
  ],
})
export class ProfilStagiaireVueProPageModule {}
